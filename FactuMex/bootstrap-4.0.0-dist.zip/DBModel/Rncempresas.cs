﻿using System;
using System.Collections.Generic;

namespace CallCenter.DBModel
{
    public partial class Rncempresas
    {
        public string Rnc { get; set; }
        public string Nombre1 { get; set; }
        public string Nombre2 { get; set; }
        public string ActividadEconomica { get; set; }
        public string Dir1 { get; set; }
        public string Dir2 { get; set; }
        public string Dir3 { get; set; }
        public string Tel { get; set; }
        public string Constitucion { get; set; }
        public string Estatus { get; set; }
        public string Regimen { get; set; }
    }
}
