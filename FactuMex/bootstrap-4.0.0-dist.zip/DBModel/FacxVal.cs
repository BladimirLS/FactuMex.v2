﻿using System;
using System.Collections.Generic;

namespace CallCenter.DBModel
{
    public partial class FacxVal
    {
        public long IdfacxVal { get; set; }
        public long? Idfac { get; set; }
        public long? Idval { get; set; }
        public DateTime? Fec { get; set; }
    }
}
