﻿using System;
using System.Collections.Generic;

namespace CallCenter.DBModel
{
    public partial class Provincia
    {
        public double Idprovincia { get; set; }
        public string Provincia1 { get; set; }
        public double? Cp { get; set; }
        public string Zona { get; set; }
    }
}
