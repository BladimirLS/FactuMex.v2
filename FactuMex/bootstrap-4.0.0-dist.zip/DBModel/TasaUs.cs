﻿using System;
using System.Collections.Generic;

namespace CallCenter.DBModel
{
    public partial class TasaUs
    {
        public long Idtasa { get; set; }
        public double? Tasa { get; set; }
        public DateTime? Fecha { get; set; }
    }
}
