﻿using System;
using System.Collections.Generic;

namespace CallCenter.DBModel
{
    public partial class Ente
    {
        public long Idente { get; set; }
        public string TipoEnte { get; set; }
        public string Nombre { get; set; }
        public string Id { get; set; }
        public string TipoId { get; set; }
        public string Correo { get; set; }
        public string Tel1 { get; set; }
        public string Tel2 { get; set; }
        public string Tel3 { get; set; }
    }
}
