﻿using System;
using System.Collections.Generic;

namespace CallCenter.DBModel
{
    public partial class LstPermiso
    {
        public long Idpermiso { get; set; }
        public string Permiso { get; set; }
        public string Grupo { get; set; }
    }
}
