﻿using System;
using System.Collections.Generic;

namespace CallCenter.DBModel
{
    public partial class FacxDesVal
    {
        public long IdfacxVal { get; set; }
        public long? Idfac { get; set; }
        public long? Idval { get; set; }
        public DateTime? Fec { get; set; }
    }
}
