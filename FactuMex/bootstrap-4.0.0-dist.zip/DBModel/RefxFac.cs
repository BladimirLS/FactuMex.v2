﻿using System;
using System.Collections.Generic;

namespace CallCenter.DBModel
{
    public partial class RefxFac
    {
        public long Idref { get; set; }
        public long? Idfac { get; set; }
        public string TipoRef { get; set; }
        public string Ref { get; set; }
    }
}
