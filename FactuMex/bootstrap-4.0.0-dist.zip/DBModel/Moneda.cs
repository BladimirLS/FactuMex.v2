﻿using System;
using System.Collections.Generic;

namespace CallCenter.DBModel
{
    public partial class Moneda
    {
        public long Idmoneda { get; set; }
        public string Moneda1 { get; set; }
    }
}
