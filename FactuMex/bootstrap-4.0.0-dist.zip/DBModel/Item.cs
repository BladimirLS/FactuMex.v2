﻿using System;
using System.Collections.Generic;

namespace CallCenter.DBModel
{
    public partial class Item
    {
        public long Iditem { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
    }
}
