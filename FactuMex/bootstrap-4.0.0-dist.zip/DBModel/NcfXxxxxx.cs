﻿using System;
using System.Collections.Generic;

namespace CallCenter.DBModel
{
    public partial class NcfXxxxxx
    {
        public long Id { get; set; }
        public string Secuencial { get; set; }
        public long? Idfactura { get; set; }
    }
}
