using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CallCenter.Models
{
    public class DTOSesion
    {
        public string Token { get; set; }
        public string Meta { get; set; }
    }
}
