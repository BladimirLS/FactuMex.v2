using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CallCenter.Models
{
    public class DTOPago
    {
        public string Puid { get; set; }
        public string Metodo { get; set; }
    }
}
