﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CallCenter.Models
{
    public class DTOAsignacion
    {
        public string idmovitem { get; set; }
        public string asignacion { get; set; }
    }
}
