using CallCenter.DBModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CallCenter.Models
{
    public class DTOValxFac
    {
        public long val{ get; set; }
        public long fac { get; set; }
        public string actn { get; set; }
    }
}
