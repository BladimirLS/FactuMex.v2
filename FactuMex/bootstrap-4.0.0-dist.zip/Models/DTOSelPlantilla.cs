﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CallCenter.Models
{
    public class DTOSelPlantilla
    {
        public string plantilla { get; set; }
        public string poliza { get; set; }
        public bool fisica { get; set; }
    }
}
