using CallCenter.DBModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CallCenter.Models
{
    public class DTOComp
    {
        public Comprobante comp { get; set; }
    }
}
